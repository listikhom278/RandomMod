package com.sixoeight.randommod;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.animal.Wolf;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.LevelAccessor;

import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import com.sixoeight.randommod.init.RandomModModItems;

@EventBusSubscriber
public class DogEssenceProcedureProcedure {

	@SubscribeEvent
	public static void onEntityInteract(PlayerInteractEvent.EntityInteract event) {
		Player player = event.getEntity();
		Entity target = event.getTarget();
		LevelAccessor world = event.getLevel();

		// Проверяем, что игрок кликает пустой рукой
		if (player.getMainHandItem().isEmpty() && target instanceof Wolf wolf) {
			
			// Проверяем, что собака НЕ приручена
			if (!wolf.isTame()) {
				
				// Шанс 70%
				if (Math.random() * 100 < 70) {
					// Выдаем предмет dog_essence (замени на актуальное имя в реестре, если будет отличаться)
					ItemStack essence = new ItemStack(RandomModModItems.DOG_ESSENCE.get());
					if (!player.getInventory().add(essence)) {
						player.drop(essence, false);
					}
				}
				
				// Анимация взмаха руки
				if (!world.isClientSide()) {
					player.swing(event.getHand(), true);
				}
				
				event.setCanceled(true);
			}
		}
	}
}