package com.sixoeight.randommod.block;

import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.CeilingHangingSignBlock;

import com.sixoeight.randommod.init.RandomModModWoodTypes;

public class AetherwoodHangingSignBlock extends CeilingHangingSignBlock {
	public AetherwoodHangingSignBlock() {
		super(RandomModModWoodTypes.AETHERWOOD_HANGING_SIGN_WOOD_TYPE, BlockBehaviour.Properties.of().sound(SoundType.HANGING_SIGN).strength(1.1f).noCollission().ignitedByLava().instrument(NoteBlockInstrument.BASS).forceSolidOn());
	}
}