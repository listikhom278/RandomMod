package com.sixoeight.randommod.block;

import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.WallSignBlock;
import net.minecraft.world.level.block.SoundType;

import com.sixoeight.randommod.init.RandomModModWoodTypes;
import com.sixoeight.randommod.init.RandomModModBlocks;

public class MangoTreeWallSignBlock extends WallSignBlock {
	public MangoTreeWallSignBlock() {
		super(RandomModModWoodTypes.MANGO_TREE_SIGN_WOOD_TYPE,
				BlockBehaviour.Properties.of().sound(SoundType.WOOD).strength(1f).noCollission().ignitedByLava().instrument(NoteBlockInstrument.BASS).forceSolidOn().dropsLike(RandomModModBlocks.MANGO_TREE_SIGN.get()));
	}
}