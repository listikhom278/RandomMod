/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package com.sixoeight.randommod.init;

import net.minecraft.world.level.block.state.properties.WoodType;
import net.minecraft.world.level.block.state.properties.BlockSetType;

public class RandomModModWoodTypes {
	public static final WoodType EBONY_SIGN_WOOD_TYPE = WoodType.register(new WoodType("random_mod:ebony_sign", BlockSetType.OAK));
	public static final WoodType EBONY_HANGING_SIGN_WOOD_TYPE = WoodType.register(new WoodType("random_mod:ebony_hanging_sign", BlockSetType.OAK));
	public static final WoodType GREENWOOD_SIGN_WOOD_TYPE = WoodType.register(new WoodType("random_mod:greenwood_sign", BlockSetType.OAK));
	public static final WoodType GREENWOOD_HANGING_SIGN_WOOD_TYPE = WoodType.register(new WoodType("random_mod:greenwood_hanging_sign", BlockSetType.OAK));
	public static final WoodType MANGO_TREE_SIGN_WOOD_TYPE = WoodType.register(new WoodType("random_mod:mango_tree_sign", BlockSetType.OAK));
	public static final WoodType MANGO_TREE_HANGING_SIGN_WOOD_TYPE = WoodType.register(new WoodType("random_mod:mango_tree_hanging_sign", BlockSetType.OAK));
	public static final WoodType AMETHYSTINEWOOD_SIGN_WOOD_TYPE = WoodType.register(new WoodType("random_mod:amethystinewood_sign", BlockSetType.OAK));
	public static final WoodType AMETHYSTINEWOOD_HANGING_SIGN_WOOD_TYPE = WoodType.register(new WoodType("random_mod:amethystinewood_hanging_sign", BlockSetType.OAK));
	public static final WoodType MOONWOOD_SIGN_WOOD_TYPE = WoodType.register(new WoodType("random_mod:moonwood_sign", BlockSetType.OAK));
	public static final WoodType MOONWOOD_HANGING_SIGN_WOOD_TYPE = WoodType.register(new WoodType("random_mod:moonwood_hanging_sign", BlockSetType.OAK));
	public static final WoodType AETHERWOOD_SIGN_WOOD_TYPE = WoodType.register(new WoodType("random_mod:aetherwood_sign", BlockSetType.OAK));
	public static final WoodType AETHERWOOD_HANGING_SIGN_WOOD_TYPE = WoodType.register(new WoodType("random_mod:aetherwood_hanging_sign", BlockSetType.OAK));
}