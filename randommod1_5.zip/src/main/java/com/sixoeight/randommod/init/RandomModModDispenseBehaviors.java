/*
 *	MCreator note: This file will be REGENERATED on each build.
 */
package com.sixoeight.randommod.init;

import net.neoforged.fml.event.lifecycle.FMLCommonSetupEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.level.block.DispenserBlock;
import net.minecraft.core.dispenser.BoatDispenseItemBehavior;

@EventBusSubscriber
public class RandomModModDispenseBehaviors {
	@SubscribeEvent
	public static void init(FMLCommonSetupEvent event) {
		event.enqueueWork(() -> {
			DispenserBlock.registerBehavior(RandomModModItems.EBONY_BOAT.get(), new BoatDispenseItemBehavior(RandomModModBoatTypes.EBONY_BOAT_TYPE.getValue()));
			DispenserBlock.registerBehavior(RandomModModItems.EBONY_CHEST_BOAT.get(), new BoatDispenseItemBehavior(RandomModModBoatTypes.EBONY_CHEST_BOAT_TYPE.getValue(), true));
			DispenserBlock.registerBehavior(RandomModModItems.GREENWOOD_BOAT.get(), new BoatDispenseItemBehavior(RandomModModBoatTypes.GREENWOOD_BOAT_TYPE.getValue()));
			DispenserBlock.registerBehavior(RandomModModItems.GREENWOOD_CHEST_BOAT.get(), new BoatDispenseItemBehavior(RandomModModBoatTypes.GREENWOOD_CHEST_BOAT_TYPE.getValue(), true));
			DispenserBlock.registerBehavior(RandomModModItems.MANGO_TREE_BOAT.get(), new BoatDispenseItemBehavior(RandomModModBoatTypes.MANGO_TREE_BOAT_TYPE.getValue()));
			DispenserBlock.registerBehavior(RandomModModItems.MANGO_TREE_CHEST_BOAT.get(), new BoatDispenseItemBehavior(RandomModModBoatTypes.MANGO_TREE_CHEST_BOAT_TYPE.getValue(), true));
			DispenserBlock.registerBehavior(RandomModModItems.AMETHYSTINEWOOD_BOAT.get(), new BoatDispenseItemBehavior(RandomModModBoatTypes.AMETHYSTINEWOOD_BOAT_TYPE.getValue()));
			DispenserBlock.registerBehavior(RandomModModItems.AMETHYSTINEWOOD_CHEST_BOAT.get(), new BoatDispenseItemBehavior(RandomModModBoatTypes.AMETHYSTINEWOOD_CHEST_BOAT_TYPE.getValue(), true));
			DispenserBlock.registerBehavior(RandomModModItems.MOONWOOD_BOAT.get(), new BoatDispenseItemBehavior(RandomModModBoatTypes.MOONWOOD_BOAT_TYPE.getValue()));
			DispenserBlock.registerBehavior(RandomModModItems.MOONWOOD_CHEST_BOAT.get(), new BoatDispenseItemBehavior(RandomModModBoatTypes.MOONWOOD_CHEST_BOAT_TYPE.getValue(), true));
			DispenserBlock.registerBehavior(RandomModModItems.AETHERWOOD_BOAT.get(), new BoatDispenseItemBehavior(RandomModModBoatTypes.AETHERWOOD_BOAT_TYPE.getValue()));
			DispenserBlock.registerBehavior(RandomModModItems.AETHERWOOD_CHEST_BOAT.get(), new BoatDispenseItemBehavior(RandomModModBoatTypes.AETHERWOOD_CHEST_BOAT_TYPE.getValue(), true));
		});
	}
}