package com.sixoeight.randommod;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.animal.Cat;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.LevelAccessor;

import net.neoforged.neoforge.event.entity.player.PlayerInteractEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import com.sixoeight.randommod.init.RandomModModItems;

@EventBusSubscriber
public class CatEssenceProcedureProcedure {

	@SubscribeEvent
	public static void onEntityInteract(PlayerInteractEvent.EntityInteract event) {
		Player player = event.getEntity();
		Entity target = event.getTarget();
		LevelAccessor world = event.getLevel();

		// Проверяем, что игрок кликает пустой рукой (в главной руке ничего нет)
		if (player.getMainHandItem().isEmpty() && target instanceof Cat cat) {
			
			// Проверяем, что кот НЕ приручен
			if (!cat.isTame()) {
				
				// Шанс 70% (случайное число от 0 до 100 меньше 70)
				if (Math.random() * 100 < 70) {
					// Выдаем предмет cat_essence в инвентарь или спавним на землю
					ItemStack essence = new ItemStack(RandomModModItems.CAT_ESSENCE.get());
					if (!player.getInventory().add(essence)) {
						player.drop(essence, false);
					}
				}
				
				// Проигрываем анимацию взмаха руки
				if (!world.isClientSide()) {
					player.swing(event.getHand(), true);
				}
				
				// Отменяем стандартное действие (чтобы кот не открывался/не садился лишний раз)
				event.setCanceled(true);
			}
		}
	}
}