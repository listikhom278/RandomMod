package com.sixoeight.randommod.item;

import net.neoforged.neoforge.common.crafting.CompoundIngredient;

import net.minecraft.world.level.Level;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Item;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionHand;
import net.minecraft.tags.ItemTags;
import net.minecraft.resources.ResourceLocation;

import com.sixoeight.randommod.procedures.FidgetClickerRightclickedProcedure;

public class FidgetClickerItem extends Item {
	public FidgetClickerItem() {
		super(new Item.Properties().durability(1969));
	}

	@Override
	public int getEnchantmentValue() {
		return 8;
	}

	@Override
	public boolean isValidRepairItem(ItemStack itemstack, ItemStack repairitem) {
		return CompoundIngredient.of(Ingredient.of(ItemTags.create(ResourceLocation.parse("c:glass_panes"))), Ingredient.of(new ItemStack(Items.IRON_NUGGET))).test(repairitem);
	}

	@Override
	public InteractionResultHolder<ItemStack> use(Level world, Player entity, InteractionHand hand) {
		InteractionResultHolder<ItemStack> ar = super.use(world, entity, hand);
		FidgetClickerRightclickedProcedure.execute(world, entity.getX(), entity.getY(), entity.getZ(), ar.getObject());
		return ar;
	}

	@Override
	public InteractionResult useOn(UseOnContext context) {
		super.useOn(context);
		FidgetClickerRightclickedProcedure.execute(context.getLevel(), context.getClickedPos().getX(), context.getClickedPos().getY(), context.getClickedPos().getZ(), context.getItemInHand());
		return InteractionResult.SUCCESS;
	}
}