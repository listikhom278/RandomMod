package com.sixoeight.randommod.item;

import net.minecraft.world.item.Item;

public class CatEssenceItem extends Item {
	public CatEssenceItem() {
		super(new Item.Properties());
	}
}