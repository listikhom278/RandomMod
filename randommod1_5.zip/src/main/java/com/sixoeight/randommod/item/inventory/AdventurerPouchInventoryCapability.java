package com.sixoeight.randommod.item.inventory;

import net.neoforged.neoforge.items.ComponentItemHandler;
import net.neoforged.neoforge.event.entity.item.ItemTossEvent;
import net.neoforged.neoforge.common.MutableDataComponentHolder;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.ItemStack;
import net.minecraft.world.entity.player.Player;
import net.minecraft.core.component.DataComponents;

import javax.annotation.Nonnull;

import com.sixoeight.randommod.world.inventory.AdventurerPouchGuiMenu;
import com.sixoeight.randommod.init.RandomModModItems;

@EventBusSubscriber
public class AdventurerPouchInventoryCapability extends ComponentItemHandler {
	@SubscribeEvent
	public static void onItemDropped(ItemTossEvent event) {
		if (event.getEntity().getItem().getItem() == RandomModModItems.ADVENTURER_POUCH.get()) {
			Player player = event.getPlayer();
			if (player.containerMenu instanceof AdventurerPouchGuiMenu)
				player.closeContainer();
		}
	}

	public AdventurerPouchInventoryCapability(MutableDataComponentHolder parent) {
		super(parent, DataComponents.CONTAINER, 9);
	}

	@Override
	public int getSlotLimit(int slot) {
		return 64;
	}

	@Override
	public boolean isItemValid(int slot, @Nonnull ItemStack stack) {
		return stack.getItem() != RandomModModItems.ADVENTURER_POUCH.get();
	}

	@Override
	public ItemStack getStackInSlot(int slot) {
		return super.getStackInSlot(slot).copy();
	}
}