package com.sixoeight.randommod.item;

import net.minecraft.world.item.Item;

public class DogEssenceItem extends Item {
	public DogEssenceItem() {
		super(new Item.Properties());
	}
}