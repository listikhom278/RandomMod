package com.sixoeight.randommod.item;

import net.minecraft.world.item.Item;
import net.minecraft.world.food.FoodProperties;

public class MangoItem extends Item {
	public MangoItem() {
		super(new Item.Properties().food((new FoodProperties.Builder()).nutrition(6).saturationModifier(2.4f).build()));
	}
}