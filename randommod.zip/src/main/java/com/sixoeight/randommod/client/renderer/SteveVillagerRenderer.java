package com.sixoeight.randommod.client.renderer;

import net.minecraft.resources.ResourceLocation;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.model.HumanoidModel;

import com.sixoeight.randommod.entity.SteveVillagerEntity;

public class SteveVillagerRenderer extends HumanoidMobRenderer<SteveVillagerEntity, HumanoidModel<SteveVillagerEntity>> {
	private final ResourceLocation entityTexture = ResourceLocation.parse("random_mod:textures/entities/cbe20ed58814c5e1.png");

	public SteveVillagerRenderer(EntityRendererProvider.Context context) {
		super(context, new HumanoidModel<SteveVillagerEntity>(context.bakeLayer(ModelLayers.PLAYER)), 0.5f);
		this.addLayer(new HumanoidArmorLayer(this, new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)), new HumanoidModel(context.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)), context.getModelManager()));
	}

	@Override
	public ResourceLocation getTextureLocation(SteveVillagerEntity entity) {
		return entityTexture;
	}
}