/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package com.sixoeight.randommod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.common.DeferredSpawnEggItem;

import net.minecraft.world.level.block.Block;
import net.minecraft.world.item.*;

import com.sixoeight.randommod.item.*;
import com.sixoeight.randommod.RandomModMod;

public class RandomModModItems {
	public static final DeferredRegister.Items REGISTRY = DeferredRegister.createItems(RandomModMod.MODID);
	public static final DeferredItem<Item> BALDI_SPAWN_EGG;
	public static final DeferredItem<Item> BALDI_BLOCK;
	public static final DeferredItem<Item> BALDI_DIMENSION;
	public static final DeferredItem<Item> BALDIS_RULER;
	public static final DeferredItem<Item> BALDI_CAT_SPAWN_EGG;
	public static final DeferredItem<Item> EMERALD_PICKAXE;
	public static final DeferredItem<Item> EMERALD_SHOVEL;
	public static final DeferredItem<Item> EMERALD_AXE;
	public static final DeferredItem<Item> EMERALD_SWORD;
	public static final DeferredItem<Item> EMERALD_HOE;
	public static final DeferredItem<Item> EMERALD_ARMOR_HELMET;
	public static final DeferredItem<Item> EMERALD_ARMOR_CHESTPLATE;
	public static final DeferredItem<Item> EMERALD_ARMOR_LEGGINGS;
	public static final DeferredItem<Item> EMERALD_ARMOR_BOOTS;
	public static final DeferredItem<Item> NETHER_GERMANIUM_ORE;
	public static final DeferredItem<Item> RAW_GERMANIUM;
	public static final DeferredItem<Item> GERMANIUM_INGOT;
	public static final DeferredItem<Item> RAW_GERMANIUM_BLOCK;
	public static final DeferredItem<Item> GERMANIUM_INGOT_BLOCK;
	public static final DeferredItem<Item> EBONY_LOG;
	public static final DeferredItem<Item> EBONY_WOOD;
	public static final DeferredItem<Item> STRIPPED_EBONY_LOG;
	public static final DeferredItem<Item> STRIPPED_EBONY_WOOD;
	public static final DeferredItem<Item> EBONY_PLANKS;
	public static final DeferredItem<Item> EBONY_LEAVES;
	public static final DeferredItem<Item> EBONY_STAIRS;
	public static final DeferredItem<Item> EBONY_SLAB;
	public static final DeferredItem<Item> EBONY_FENCE;
	public static final DeferredItem<Item> EBONY_FENCE_GATE;
	public static final DeferredItem<Item> EBONY_DOOR;
	public static final DeferredItem<Item> EBONY_TRAPDOOR;
	public static final DeferredItem<Item> EBONY_PRESSURE_PLATE;
	public static final DeferredItem<Item> EBONY_BUTTON;
	public static final DeferredItem<Item> EBONY_SIGN;
	public static final DeferredItem<Item> EBONY_HANGING_SIGN;
	public static final DeferredItem<Item> EBONY_BOAT;
	public static final DeferredItem<Item> EBONY_CHEST_BOAT;
	public static final DeferredItem<Item> GREENWOOD_LOG;
	public static final DeferredItem<Item> GREENWOOD_WOOD;
	public static final DeferredItem<Item> STRIPPED_GREENWOOD_LOG;
	public static final DeferredItem<Item> STRIPPED_GREENWOOD_WOOD;
	public static final DeferredItem<Item> GREENWOOD_PLANKS;
	public static final DeferredItem<Item> GREENWOOD_LEAVES;
	public static final DeferredItem<Item> GREENWOOD_STAIRS;
	public static final DeferredItem<Item> GREENWOOD_SLAB;
	public static final DeferredItem<Item> GREENWOOD_FENCE;
	public static final DeferredItem<Item> GREENWOOD_FENCE_GATE;
	public static final DeferredItem<Item> GREENWOOD_DOOR;
	public static final DeferredItem<Item> GREENWOOD_TRAPDOOR;
	public static final DeferredItem<Item> GREENWOOD_PRESSURE_PLATE;
	public static final DeferredItem<Item> GREENWOOD_BUTTON;
	public static final DeferredItem<Item> GREENWOOD_SIGN;
	public static final DeferredItem<Item> GREENWOOD_HANGING_SIGN;
	public static final DeferredItem<Item> GREENWOOD_BOAT;
	public static final DeferredItem<Item> GREENWOOD_CHEST_BOAT;
	public static final DeferredItem<Item> GREEN_WOOD_SAPLING;
	public static final DeferredItem<Item> EBONY_SAPLING;
	public static final DeferredItem<Item> RANDOM_TABLE;
	public static final DeferredItem<Item> MUSIC_DISC;
	public static final DeferredItem<Item> ELECTRUM_INGOT;
	public static final DeferredItem<Item> ELECTRUM_PICKAXE;
	public static final DeferredItem<Item> ELECTRUM_AXE;
	public static final DeferredItem<Item> ELECTRUM_SWORD;
	public static final DeferredItem<Item> ELECTRUM_SHOVEL;
	public static final DeferredItem<Item> ELECTRUM_HOE;
	public static final DeferredItem<Item> ELECTRUM_ARMOR_HELMET;
	public static final DeferredItem<Item> ELECTRUM_ARMOR_CHESTPLATE;
	public static final DeferredItem<Item> ELECTRUM_ARMOR_LEGGINGS;
	public static final DeferredItem<Item> ELECTRUM_ARMOR_BOOTS;
	public static final DeferredItem<Item> RUBY;
	public static final DeferredItem<Item> RUBY_ORE;
	public static final DeferredItem<Item> RUBY_BLOCK;
	public static final DeferredItem<Item> RUBY_PICKAXE;
	public static final DeferredItem<Item> RUBY_AXE;
	public static final DeferredItem<Item> RUBY_SWORD;
	public static final DeferredItem<Item> RUBY_SHOVEL;
	public static final DeferredItem<Item> RUBY_HOE;
	public static final DeferredItem<Item> RUBY_ARMOR_HELMET;
	public static final DeferredItem<Item> RUBY_ARMOR_CHESTPLATE;
	public static final DeferredItem<Item> RUBY_ARMOR_LEGGINGS;
	public static final DeferredItem<Item> RUBY_ARMOR_BOOTS;
	public static final DeferredItem<Item> ELECTRUM_INGOT_BLOCK;
	public static final DeferredItem<Item> STONE_WALL;
	public static final DeferredItem<Item> COMPRESSED_COAL_BLOCK;
	public static final DeferredItem<Item> SMOOTH_STONE_STAIRS;
	public static final DeferredItem<Item> SMOOTH_STONE_WALL;
	public static final DeferredItem<Item> BRICKS_FENCE;
	public static final DeferredItem<Item> IRON_AMETHYST_ALLOY;
	public static final DeferredItem<Item> IRON_AMETHYST_PICKAXE;
	public static final DeferredItem<Item> IRON_AMETHYST_AXE;
	public static final DeferredItem<Item> IRON_AMETHYST_SWORD;
	public static final DeferredItem<Item> IRON_AMETHYST_SHOVEL;
	public static final DeferredItem<Item> IRON_AMETHYST_HOE;
	public static final DeferredItem<Item> IRON_AMETHYST_ARMOR_HELMET;
	public static final DeferredItem<Item> IRON_AMETHYST_ARMOR_CHESTPLATE;
	public static final DeferredItem<Item> IRON_AMETHYST_ARMOR_LEGGINGS;
	public static final DeferredItem<Item> IRON_AMETHYST_ARMOR_BOOTS;
	public static final DeferredItem<Item> IRON_AMETHYST_ALLOY_BLOCK;
	public static final DeferredItem<Item> LAPIS_SOUP;
	public static final DeferredItem<Item> BAKED_APPLE;
	public static final DeferredItem<Item> DIRT_DIMENSION;
	public static final DeferredItem<Item> INF_FOREST_DIMENSION;
	public static final DeferredItem<Item> ROSE_GOLD_INGOT;
	public static final DeferredItem<Item> ROSE_GOLD_BLOCK;
	public static final DeferredItem<Item> ROSE_GOLD_PICKAXE;
	public static final DeferredItem<Item> ROSE_GOLD_AXE;
	public static final DeferredItem<Item> ROSE_GOLD_SWORD;
	public static final DeferredItem<Item> ROSE_GOLD_SHOVEL;
	public static final DeferredItem<Item> ROSE_GOLD_HOE;
	public static final DeferredItem<Item> ROSE_GOLD_ARMOR_HELMET;
	public static final DeferredItem<Item> ROSE_GOLD_ARMOR_CHESTPLATE;
	public static final DeferredItem<Item> ROSE_GOLD_ARMOR_LEGGINGS;
	public static final DeferredItem<Item> ROSE_GOLD_ARMOR_BOOTS;
	public static final DeferredItem<Item> MYSTERY_BLOCK;
	public static final DeferredItem<Item> MYSTERY_DIMENSION;
	public static final DeferredItem<Item> BLUESTONE_DUST;
	public static final DeferredItem<Item> BLUESTONE_ORE;
	public static final DeferredItem<Item> BLUESTONE_BLOCK;
	public static final DeferredItem<Item> BLUESTONE_PICKAXE;
	public static final DeferredItem<Item> BLUESTONE_AXE;
	public static final DeferredItem<Item> BLUESTONE_SWORD;
	public static final DeferredItem<Item> BLUESTONE_SHOVEL;
	public static final DeferredItem<Item> BLUESTONE_HOE;
	public static final DeferredItem<Item> BLUESTONE_ARMOR_HELMET;
	public static final DeferredItem<Item> BLUESTONE_ARMOR_CHESTPLATE;
	public static final DeferredItem<Item> BLUESTONE_ARMOR_LEGGINGS;
	public static final DeferredItem<Item> BLUESTONE_ARMOR_BOOTS;
	public static final DeferredItem<Item> STEVE_VILLAGER_SPAWN_EGG;
	public static final DeferredItem<Item> ALEX_VILLAGER_SPAWN_EGG;
	public static final DeferredItem<Item> SALTPETER_DUST;
	public static final DeferredItem<Item> SALTPETER_ORE;
	public static final DeferredItem<Item> SALTPETER_BLOCK;
	public static final DeferredItem<Item> SULFUR_DUST;
	public static final DeferredItem<Item> SULFUR_ORE;
	public static final DeferredItem<Item> SULFUR_BLOCK;
	static {
		BALDI_SPAWN_EGG = REGISTRY.register("baldi_spawn_egg", () -> new DeferredSpawnEggItem(RandomModModEntities.BALDI, -10027213, -13312, new Item.Properties()));
		BALDI_BLOCK = block(RandomModModBlocks.BALDI_BLOCK, new Item.Properties().fireResistant());
		BALDI_DIMENSION = REGISTRY.register("baldi_dimension", BaldiDimensionItem::new);
		BALDIS_RULER = REGISTRY.register("baldis_ruler", BaldisRulerItem::new);
		BALDI_CAT_SPAWN_EGG = REGISTRY.register("baldi_cat_spawn_egg", () -> new DeferredSpawnEggItem(RandomModModEntities.BALDI_CAT, -13369600, -16763905, new Item.Properties()));
		EMERALD_PICKAXE = REGISTRY.register("emerald_pickaxe", EmeraldPickaxeItem::new);
		EMERALD_SHOVEL = REGISTRY.register("emerald_shovel", EmeraldShovelItem::new);
		EMERALD_AXE = REGISTRY.register("emerald_axe", EmeraldAxeItem::new);
		EMERALD_SWORD = REGISTRY.register("emerald_sword", EmeraldSwordItem::new);
		EMERALD_HOE = REGISTRY.register("emerald_hoe", EmeraldHoeItem::new);
		EMERALD_ARMOR_HELMET = REGISTRY.register("emerald_armor_helmet", EmeraldArmorItem.Helmet::new);
		EMERALD_ARMOR_CHESTPLATE = REGISTRY.register("emerald_armor_chestplate", EmeraldArmorItem.Chestplate::new);
		EMERALD_ARMOR_LEGGINGS = REGISTRY.register("emerald_armor_leggings", EmeraldArmorItem.Leggings::new);
		EMERALD_ARMOR_BOOTS = REGISTRY.register("emerald_armor_boots", EmeraldArmorItem.Boots::new);
		NETHER_GERMANIUM_ORE = block(RandomModModBlocks.NETHER_GERMANIUM_ORE);
		RAW_GERMANIUM = REGISTRY.register("raw_germanium", RawGermaniumItem::new);
		GERMANIUM_INGOT = REGISTRY.register("germanium_ingot", GermaniumIngotItem::new);
		RAW_GERMANIUM_BLOCK = block(RandomModModBlocks.RAW_GERMANIUM_BLOCK);
		GERMANIUM_INGOT_BLOCK = block(RandomModModBlocks.GERMANIUM_INGOT_BLOCK);
		EBONY_LOG = block(RandomModModBlocks.EBONY_LOG);
		EBONY_WOOD = block(RandomModModBlocks.EBONY_WOOD);
		STRIPPED_EBONY_LOG = block(RandomModModBlocks.STRIPPED_EBONY_LOG);
		STRIPPED_EBONY_WOOD = block(RandomModModBlocks.STRIPPED_EBONY_WOOD);
		EBONY_PLANKS = block(RandomModModBlocks.EBONY_PLANKS);
		EBONY_LEAVES = block(RandomModModBlocks.EBONY_LEAVES);
		EBONY_STAIRS = block(RandomModModBlocks.EBONY_STAIRS);
		EBONY_SLAB = block(RandomModModBlocks.EBONY_SLAB);
		EBONY_FENCE = block(RandomModModBlocks.EBONY_FENCE);
		EBONY_FENCE_GATE = block(RandomModModBlocks.EBONY_FENCE_GATE);
		EBONY_DOOR = doubleBlock(RandomModModBlocks.EBONY_DOOR);
		EBONY_TRAPDOOR = block(RandomModModBlocks.EBONY_TRAPDOOR);
		EBONY_PRESSURE_PLATE = block(RandomModModBlocks.EBONY_PRESSURE_PLATE);
		EBONY_BUTTON = block(RandomModModBlocks.EBONY_BUTTON);
		EBONY_SIGN = signBlock(RandomModModBlocks.EBONY_SIGN, RandomModModBlocks.EBONY_WALL_SIGN, new Item.Properties().stacksTo(16));
		EBONY_HANGING_SIGN = hangingSignBlock(RandomModModBlocks.EBONY_HANGING_SIGN, RandomModModBlocks.EBONY_WALL_HANGING_SIGN, new Item.Properties().stacksTo(16));
		EBONY_BOAT = REGISTRY.register("ebony_boat", () -> new BoatItem(false, RandomModModBoatTypes.EBONY_BOAT_TYPE.getValue(), new Item.Properties().stacksTo(1)));
		EBONY_CHEST_BOAT = REGISTRY.register("ebony_chest_boat", () -> new BoatItem(true, RandomModModBoatTypes.EBONY_CHEST_BOAT_TYPE.getValue(), new Item.Properties().stacksTo(1)));
		GREENWOOD_LOG = block(RandomModModBlocks.GREENWOOD_LOG);
		GREENWOOD_WOOD = block(RandomModModBlocks.GREENWOOD_WOOD);
		STRIPPED_GREENWOOD_LOG = block(RandomModModBlocks.STRIPPED_GREENWOOD_LOG);
		STRIPPED_GREENWOOD_WOOD = block(RandomModModBlocks.STRIPPED_GREENWOOD_WOOD);
		GREENWOOD_PLANKS = block(RandomModModBlocks.GREENWOOD_PLANKS);
		GREENWOOD_LEAVES = block(RandomModModBlocks.GREENWOOD_LEAVES);
		GREENWOOD_STAIRS = block(RandomModModBlocks.GREENWOOD_STAIRS);
		GREENWOOD_SLAB = block(RandomModModBlocks.GREENWOOD_SLAB);
		GREENWOOD_FENCE = block(RandomModModBlocks.GREENWOOD_FENCE);
		GREENWOOD_FENCE_GATE = block(RandomModModBlocks.GREENWOOD_FENCE_GATE);
		GREENWOOD_DOOR = doubleBlock(RandomModModBlocks.GREENWOOD_DOOR);
		GREENWOOD_TRAPDOOR = block(RandomModModBlocks.GREENWOOD_TRAPDOOR);
		GREENWOOD_PRESSURE_PLATE = block(RandomModModBlocks.GREENWOOD_PRESSURE_PLATE);
		GREENWOOD_BUTTON = block(RandomModModBlocks.GREENWOOD_BUTTON);
		GREENWOOD_SIGN = signBlock(RandomModModBlocks.GREENWOOD_SIGN, RandomModModBlocks.GREENWOOD_WALL_SIGN, new Item.Properties().stacksTo(16));
		GREENWOOD_HANGING_SIGN = hangingSignBlock(RandomModModBlocks.GREENWOOD_HANGING_SIGN, RandomModModBlocks.GREENWOOD_WALL_HANGING_SIGN, new Item.Properties().stacksTo(16));
		GREENWOOD_BOAT = REGISTRY.register("greenwood_boat", () -> new BoatItem(false, RandomModModBoatTypes.GREENWOOD_BOAT_TYPE.getValue(), new Item.Properties().stacksTo(1)));
		GREENWOOD_CHEST_BOAT = REGISTRY.register("greenwood_chest_boat", () -> new BoatItem(true, RandomModModBoatTypes.GREENWOOD_CHEST_BOAT_TYPE.getValue(), new Item.Properties().stacksTo(1)));
		GREEN_WOOD_SAPLING = block(RandomModModBlocks.GREEN_WOOD_SAPLING);
		EBONY_SAPLING = block(RandomModModBlocks.EBONY_SAPLING);
		RANDOM_TABLE = block(RandomModModBlocks.RANDOM_TABLE);
		MUSIC_DISC = REGISTRY.register("music_disc", MusicDiscItem::new);
		ELECTRUM_INGOT = REGISTRY.register("electrum_ingot", ElectrumIngotItem::new);
		ELECTRUM_PICKAXE = REGISTRY.register("electrum_pickaxe", ElectrumPickaxeItem::new);
		ELECTRUM_AXE = REGISTRY.register("electrum_axe", ElectrumAxeItem::new);
		ELECTRUM_SWORD = REGISTRY.register("electrum_sword", ElectrumSwordItem::new);
		ELECTRUM_SHOVEL = REGISTRY.register("electrum_shovel", ElectrumShovelItem::new);
		ELECTRUM_HOE = REGISTRY.register("electrum_hoe", ElectrumHoeItem::new);
		ELECTRUM_ARMOR_HELMET = REGISTRY.register("electrum_armor_helmet", ElectrumArmorItem.Helmet::new);
		ELECTRUM_ARMOR_CHESTPLATE = REGISTRY.register("electrum_armor_chestplate", ElectrumArmorItem.Chestplate::new);
		ELECTRUM_ARMOR_LEGGINGS = REGISTRY.register("electrum_armor_leggings", ElectrumArmorItem.Leggings::new);
		ELECTRUM_ARMOR_BOOTS = REGISTRY.register("electrum_armor_boots", ElectrumArmorItem.Boots::new);
		RUBY = REGISTRY.register("ruby", RubyItem::new);
		RUBY_ORE = block(RandomModModBlocks.RUBY_ORE);
		RUBY_BLOCK = block(RandomModModBlocks.RUBY_BLOCK);
		RUBY_PICKAXE = REGISTRY.register("ruby_pickaxe", RubyPickaxeItem::new);
		RUBY_AXE = REGISTRY.register("ruby_axe", RubyAxeItem::new);
		RUBY_SWORD = REGISTRY.register("ruby_sword", RubySwordItem::new);
		RUBY_SHOVEL = REGISTRY.register("ruby_shovel", RubyShovelItem::new);
		RUBY_HOE = REGISTRY.register("ruby_hoe", RubyHoeItem::new);
		RUBY_ARMOR_HELMET = REGISTRY.register("ruby_armor_helmet", RubyArmorItem.Helmet::new);
		RUBY_ARMOR_CHESTPLATE = REGISTRY.register("ruby_armor_chestplate", RubyArmorItem.Chestplate::new);
		RUBY_ARMOR_LEGGINGS = REGISTRY.register("ruby_armor_leggings", RubyArmorItem.Leggings::new);
		RUBY_ARMOR_BOOTS = REGISTRY.register("ruby_armor_boots", RubyArmorItem.Boots::new);
		ELECTRUM_INGOT_BLOCK = block(RandomModModBlocks.ELECTRUM_INGOT_BLOCK);
		STONE_WALL = block(RandomModModBlocks.STONE_WALL);
		COMPRESSED_COAL_BLOCK = block(RandomModModBlocks.COMPRESSED_COAL_BLOCK);
		SMOOTH_STONE_STAIRS = block(RandomModModBlocks.SMOOTH_STONE_STAIRS);
		SMOOTH_STONE_WALL = block(RandomModModBlocks.SMOOTH_STONE_WALL);
		BRICKS_FENCE = block(RandomModModBlocks.BRICKS_FENCE);
		IRON_AMETHYST_ALLOY = REGISTRY.register("iron_amethyst_alloy", IronAmethystAlloyItem::new);
		IRON_AMETHYST_PICKAXE = REGISTRY.register("iron_amethyst_pickaxe", IronAmethystPickaxeItem::new);
		IRON_AMETHYST_AXE = REGISTRY.register("iron_amethyst_axe", IronAmethystAxeItem::new);
		IRON_AMETHYST_SWORD = REGISTRY.register("iron_amethyst_sword", IronAmethystSwordItem::new);
		IRON_AMETHYST_SHOVEL = REGISTRY.register("iron_amethyst_shovel", IronAmethystShovelItem::new);
		IRON_AMETHYST_HOE = REGISTRY.register("iron_amethyst_hoe", IronAmethystHoeItem::new);
		IRON_AMETHYST_ARMOR_HELMET = REGISTRY.register("iron_amethyst_armor_helmet", IronAmethystArmorItem.Helmet::new);
		IRON_AMETHYST_ARMOR_CHESTPLATE = REGISTRY.register("iron_amethyst_armor_chestplate", IronAmethystArmorItem.Chestplate::new);
		IRON_AMETHYST_ARMOR_LEGGINGS = REGISTRY.register("iron_amethyst_armor_leggings", IronAmethystArmorItem.Leggings::new);
		IRON_AMETHYST_ARMOR_BOOTS = REGISTRY.register("iron_amethyst_armor_boots", IronAmethystArmorItem.Boots::new);
		IRON_AMETHYST_ALLOY_BLOCK = block(RandomModModBlocks.IRON_AMETHYST_ALLOY_BLOCK);
		LAPIS_SOUP = REGISTRY.register("lapis_soup", LapisSoupItem::new);
		BAKED_APPLE = REGISTRY.register("baked_apple", BakedAppleItem::new);
		DIRT_DIMENSION = REGISTRY.register("dirt_dimension", DirtDimensionItem::new);
		INF_FOREST_DIMENSION = REGISTRY.register("inf_forest_dimension", InfForestDimensionItem::new);
		ROSE_GOLD_INGOT = REGISTRY.register("rose_gold_ingot", RoseGoldIngotItem::new);
		ROSE_GOLD_BLOCK = block(RandomModModBlocks.ROSE_GOLD_BLOCK);
		ROSE_GOLD_PICKAXE = REGISTRY.register("rose_gold_pickaxe", RoseGoldPickaxeItem::new);
		ROSE_GOLD_AXE = REGISTRY.register("rose_gold_axe", RoseGoldAxeItem::new);
		ROSE_GOLD_SWORD = REGISTRY.register("rose_gold_sword", RoseGoldSwordItem::new);
		ROSE_GOLD_SHOVEL = REGISTRY.register("rose_gold_shovel", RoseGoldShovelItem::new);
		ROSE_GOLD_HOE = REGISTRY.register("rose_gold_hoe", RoseGoldHoeItem::new);
		ROSE_GOLD_ARMOR_HELMET = REGISTRY.register("rose_gold_armor_helmet", RoseGoldArmorItem.Helmet::new);
		ROSE_GOLD_ARMOR_CHESTPLATE = REGISTRY.register("rose_gold_armor_chestplate", RoseGoldArmorItem.Chestplate::new);
		ROSE_GOLD_ARMOR_LEGGINGS = REGISTRY.register("rose_gold_armor_leggings", RoseGoldArmorItem.Leggings::new);
		ROSE_GOLD_ARMOR_BOOTS = REGISTRY.register("rose_gold_armor_boots", RoseGoldArmorItem.Boots::new);
		MYSTERY_BLOCK = block(RandomModModBlocks.MYSTERY_BLOCK);
		MYSTERY_DIMENSION = REGISTRY.register("mystery_dimension", MysteryDimensionItem::new);
		BLUESTONE_DUST = REGISTRY.register("bluestone_dust", BluestoneDustItem::new);
		BLUESTONE_ORE = block(RandomModModBlocks.BLUESTONE_ORE);
		BLUESTONE_BLOCK = block(RandomModModBlocks.BLUESTONE_BLOCK);
		BLUESTONE_PICKAXE = REGISTRY.register("bluestone_pickaxe", BluestonePickaxeItem::new);
		BLUESTONE_AXE = REGISTRY.register("bluestone_axe", BluestoneAxeItem::new);
		BLUESTONE_SWORD = REGISTRY.register("bluestone_sword", BluestoneSwordItem::new);
		BLUESTONE_SHOVEL = REGISTRY.register("bluestone_shovel", BluestoneShovelItem::new);
		BLUESTONE_HOE = REGISTRY.register("bluestone_hoe", BluestoneHoeItem::new);
		BLUESTONE_ARMOR_HELMET = REGISTRY.register("bluestone_armor_helmet", BluestoneArmorItem.Helmet::new);
		BLUESTONE_ARMOR_CHESTPLATE = REGISTRY.register("bluestone_armor_chestplate", BluestoneArmorItem.Chestplate::new);
		BLUESTONE_ARMOR_LEGGINGS = REGISTRY.register("bluestone_armor_leggings", BluestoneArmorItem.Leggings::new);
		BLUESTONE_ARMOR_BOOTS = REGISTRY.register("bluestone_armor_boots", BluestoneArmorItem.Boots::new);
		STEVE_VILLAGER_SPAWN_EGG = REGISTRY.register("steve_villager_spawn_egg", () -> new DeferredSpawnEggItem(RandomModModEntities.STEVE_VILLAGER, -13369345, -13434625, new Item.Properties()));
		ALEX_VILLAGER_SPAWN_EGG = REGISTRY.register("alex_villager_spawn_egg", () -> new DeferredSpawnEggItem(RandomModModEntities.ALEX_VILLAGER, -6684775, -26368, new Item.Properties()));
		SALTPETER_DUST = REGISTRY.register("saltpeter_dust", SaltpeterDustItem::new);
		SALTPETER_ORE = block(RandomModModBlocks.SALTPETER_ORE);
		SALTPETER_BLOCK = block(RandomModModBlocks.SALTPETER_BLOCK);
		SULFUR_DUST = REGISTRY.register("sulfur_dust", SulfurDustItem::new);
		SULFUR_ORE = block(RandomModModBlocks.SULFUR_ORE);
		SULFUR_BLOCK = block(RandomModModBlocks.SULFUR_BLOCK);
	}

	// Start of user code block custom items
	// End of user code block custom items
	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block) {
		return block(block, new Item.Properties());
	}

	private static DeferredItem<Item> block(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.register(block.getId().getPath(), () -> new BlockItem(block.get(), properties));
	}

	private static DeferredItem<Item> doubleBlock(DeferredHolder<Block, Block> block) {
		return doubleBlock(block, new Item.Properties());
	}

	private static DeferredItem<Item> doubleBlock(DeferredHolder<Block, Block> block, Item.Properties properties) {
		return REGISTRY.register(block.getId().getPath(), () -> new DoubleHighBlockItem(block.get(), properties));
	}

	private static DeferredItem<Item> signBlock(DeferredHolder<Block, Block> block, DeferredHolder<Block, Block> wallBlock) {
		return signBlock(block, wallBlock, new Item.Properties());
	}

	private static DeferredItem<Item> signBlock(DeferredHolder<Block, Block> block, DeferredHolder<Block, Block> wallBlock, Item.Properties properties) {
		return REGISTRY.register(block.getId().getPath(), () -> new SignItem(properties, block.get(), wallBlock.get()));
	}

	private static DeferredItem<Item> hangingSignBlock(DeferredHolder<Block, Block> block, DeferredHolder<Block, Block> wallBlock) {
		return hangingSignBlock(block, wallBlock, new Item.Properties());
	}

	private static DeferredItem<Item> hangingSignBlock(DeferredHolder<Block, Block> block, DeferredHolder<Block, Block> wallBlock, Item.Properties properties) {
		return REGISTRY.register(block.getId().getPath(), () -> new HangingSignItem(block.get(), wallBlock.get(), properties));
	}
}