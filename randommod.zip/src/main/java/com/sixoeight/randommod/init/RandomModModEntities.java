/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package com.sixoeight.randommod.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.event.entity.RegisterSpawnPlacementsEvent;
import net.neoforged.neoforge.event.entity.EntityAttributeCreationEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.Entity;
import net.minecraft.core.registries.Registries;

import com.sixoeight.randommod.entity.SteveVillagerEntity;
import com.sixoeight.randommod.entity.BaldiEntity;
import com.sixoeight.randommod.entity.BaldiCatEntity;
import com.sixoeight.randommod.entity.AlexVillagerEntity;
import com.sixoeight.randommod.RandomModMod;

@EventBusSubscriber
public class RandomModModEntities {
	public static final DeferredRegister<EntityType<?>> REGISTRY = DeferredRegister.create(Registries.ENTITY_TYPE, RandomModMod.MODID);
	public static final DeferredHolder<EntityType<?>, EntityType<BaldiEntity>> BALDI = register("baldi",
			EntityType.Builder.<BaldiEntity>of(BaldiEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.ridingOffset(-0.6f).sized(0.6f, 1.8f));
	public static final DeferredHolder<EntityType<?>, EntityType<BaldiCatEntity>> BALDI_CAT = register("baldi_cat",
			EntityType.Builder.<BaldiCatEntity>of(BaldiCatEntity::new, MobCategory.CREATURE).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.sized(0.6f, 0.7f));
	public static final DeferredHolder<EntityType<?>, EntityType<SteveVillagerEntity>> STEVE_VILLAGER = register("steve_villager",
			EntityType.Builder.<SteveVillagerEntity>of(SteveVillagerEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.ridingOffset(-0.6f).sized(0.6f, 1.8f));
	public static final DeferredHolder<EntityType<?>, EntityType<AlexVillagerEntity>> ALEX_VILLAGER = register("alex_villager",
			EntityType.Builder.<AlexVillagerEntity>of(AlexVillagerEntity::new, MobCategory.MONSTER).setShouldReceiveVelocityUpdates(true).setTrackingRange(64).setUpdateInterval(3)

					.ridingOffset(-0.6f).sized(0.6f, 1.8f));

	// Start of user code block custom entities
	// End of user code block custom entities
	private static <T extends Entity> DeferredHolder<EntityType<?>, EntityType<T>> register(String registryname, EntityType.Builder<T> entityTypeBuilder) {
		return REGISTRY.register(registryname, () -> (EntityType<T>) entityTypeBuilder.build(registryname));
	}

	@SubscribeEvent
	public static void init(RegisterSpawnPlacementsEvent event) {
		BaldiEntity.init(event);
		BaldiCatEntity.init(event);
		SteveVillagerEntity.init(event);
		AlexVillagerEntity.init(event);
	}

	@SubscribeEvent
	public static void registerAttributes(EntityAttributeCreationEvent event) {
		event.put(BALDI.get(), BaldiEntity.createAttributes().build());
		event.put(BALDI_CAT.get(), BaldiCatEntity.createAttributes().build());
		event.put(STEVE_VILLAGER.get(), SteveVillagerEntity.createAttributes().build());
		event.put(ALEX_VILLAGER.get(), AlexVillagerEntity.createAttributes().build());
	}
}