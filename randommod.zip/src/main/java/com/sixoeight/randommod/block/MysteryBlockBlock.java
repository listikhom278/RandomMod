package com.sixoeight.randommod.block;

import net.minecraft.world.level.material.MapColor;
import net.minecraft.world.level.block.state.properties.NoteBlockInstrument;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.Block;

public class MysteryBlockBlock extends Block {
	public MysteryBlockBlock() {
		super(BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_YELLOW).strength(2f, 10f).requiresCorrectToolForDrops().instrument(NoteBlockInstrument.ZOMBIE));
	}
}