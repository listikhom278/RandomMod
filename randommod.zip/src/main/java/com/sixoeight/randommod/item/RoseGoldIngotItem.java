package com.sixoeight.randommod.item;

import net.minecraft.world.item.Item;

public class RoseGoldIngotItem extends Item {
	public RoseGoldIngotItem() {
		super(new Item.Properties());
	}
}