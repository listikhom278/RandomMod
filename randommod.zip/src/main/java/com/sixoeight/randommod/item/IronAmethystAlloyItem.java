package com.sixoeight.randommod.item;

import net.minecraft.world.item.Item;

public class IronAmethystAlloyItem extends Item {
	public IronAmethystAlloyItem() {
		super(new Item.Properties());
	}
}