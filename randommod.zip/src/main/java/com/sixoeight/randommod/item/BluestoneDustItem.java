package com.sixoeight.randommod.item;

import net.minecraft.world.item.Item;

public class BluestoneDustItem extends Item {
	public BluestoneDustItem() {
		super(new Item.Properties());
	}
}