package com.sixoeight.randommod.item;

import net.minecraft.world.item.Item;

public class SulfurDustItem extends Item {
	public SulfurDustItem() {
		super(new Item.Properties());
	}
}