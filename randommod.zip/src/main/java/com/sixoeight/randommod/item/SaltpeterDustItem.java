package com.sixoeight.randommod.item;

import net.minecraft.world.item.Item;

public class SaltpeterDustItem extends Item {
	public SaltpeterDustItem() {
		super(new Item.Properties());
	}
}