@echo off
title MCreator Gradle Runner
color 0A

echo Отстанавливаем застрявшие демоны Gradle...
call gradlew.bat --stop

echo Запускаем клиент с подробным логом...
call gradlew.bat runClient --stacktrace

pause